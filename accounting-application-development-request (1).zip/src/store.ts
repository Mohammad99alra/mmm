import { Product, Sale, Purchase, Customer, Expense, AppSettings, CurrencyType } from './types';

const STORAGE_KEYS = {
  products: 'acc_products',
  sales: 'acc_sales',
  purchases: 'acc_purchases',
  customers: 'acc_customers',
  expenses: 'acc_expenses',
  settings: 'acc_settings',
};

function load<T>(key: string, fallback: T[]): T[] {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch {
    return fallback;
  }
}

function save<T>(key: string, data: T[]) {
  localStorage.setItem(key, JSON.stringify(data));
}

export function getProducts(): Product[] { return load<Product>(STORAGE_KEYS.products, []); }
export function saveProducts(products: Product[]) { save(STORAGE_KEYS.products, products); }

export function getSales(): Sale[] { return load<Sale>(STORAGE_KEYS.sales, []); }
export function saveSales(sales: Sale[]) { save(STORAGE_KEYS.sales, sales); }

export function getPurchases(): Purchase[] { return load<Purchase>(STORAGE_KEYS.purchases, []); }
export function savePurchases(purchases: Purchase[]) { save(STORAGE_KEYS.purchases, purchases); }

export function getCustomers(): Customer[] { return load<Customer>(STORAGE_KEYS.customers, []); }
export function saveCustomers(customers: Customer[]) { save(STORAGE_KEYS.customers, customers); }

export function getExpenses(): Expense[] { return load<Expense>(STORAGE_KEYS.expenses, []); }
export function saveExpenses(expenses: Expense[]) { save(STORAGE_KEYS.expenses, expenses); }

export function getSettings(): AppSettings {
  try {
    const data = localStorage.getItem(STORAGE_KEYS.settings);
    return data ? JSON.parse(data) : { currency: 'USD', businessName: 'نظام المحاسبة' };
  } catch {
    return { currency: 'USD', businessName: 'نظام المحاسبة' };
  }
}

export function saveSettings(settings: AppSettings) {
  localStorage.setItem(STORAGE_KEYS.settings, JSON.stringify(settings));
}

export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

const CURRENCY_SYMBOLS: Record<CurrencyType, string> = {
  USD: '$',
  SAR: 'ر.س',
  IQD: 'د.ع',
  SYP: 'ل.س',
  AED: 'د.إ',
  EGP: 'ج.م',
  EUR: '€',
};

export function formatCurrency(amount: number): string {
  const settings = getSettings();
  const symbol = CURRENCY_SYMBOLS[settings.currency] || '$';
  return amount.toLocaleString('ar-SA', { minimumFractionDigits: 0, maximumFractionDigits: 2 }) + ' ' + symbol;
}

export function formatDate(dateStr: string): string {
  const date = new Date(dateStr);
  return date.toLocaleDateString('ar-SA', { year: 'numeric', month: 'short', day: 'numeric' });
}

export function getTodayStr(): string {
  return new Date().toISOString().split('T')[0];
}

export function exportAllData(): string {
  const data = {
    products: getProducts(),
    sales: getSales(),
    purchases: getPurchases(),
    customers: getCustomers(),
    expenses: getExpenses(),
    settings: getSettings(),
    exportDate: new Date().toISOString(),
  };
  return JSON.stringify(data, null, 2);
}

export function importAllData(jsonStr: string): boolean {
  try {
    const data = JSON.parse(jsonStr);
    if (data.products) saveProducts(data.products);
    if (data.sales) saveSales(data.sales);
    if (data.purchases) savePurchases(data.purchases);
    if (data.customers) saveCustomers(data.customers);
    if (data.expenses) saveExpenses(data.expenses);
    if (data.settings) saveSettings(data.settings);
    return true;
  } catch {
    return false;
  }
}
