import { useState, useEffect, useCallback } from 'react';
import { Menu, X } from 'lucide-react';
import { ActivePage, Product, Sale, Purchase, Customer, Expense } from './types';
import {
  getProducts, saveProducts,
  getSales, saveSales,
  getPurchases, savePurchases,
  getCustomers, saveCustomers,
  getExpenses, saveExpenses,
  getSettings,
} from './store';
import { Sidebar } from './components/Sidebar';
import { Dashboard } from './components/Dashboard';
import { Products } from './components/Products';
import { Inventory } from './components/Inventory';
import { Sales } from './components/Sales';
import { Purchases } from './components/Purchases';
import { Profits } from './components/Profits';
import { Debts } from './components/Debts';
import { Expenses } from './components/Expenses';
import { SettingsPage } from './components/SettingsPage';

export function App() {
  const [activePage, setActivePage] = useState<ActivePage>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [products, setProductsState] = useState<Product[]>([]);
  const [sales, setSalesState] = useState<Sale[]>([]);
  const [purchases, setPurchasesState] = useState<Purchase[]>([]);
  const [customers, setCustomersState] = useState<Customer[]>([]);
  const [expenses, setExpensesState] = useState<Expense[]>([]);
  const [businessName, setBusinessName] = useState('نظام المحاسبة');

  const loadData = useCallback(() => {
    setProductsState(getProducts());
    setSalesState(getSales());
    setPurchasesState(getPurchases());
    setCustomersState(getCustomers());
    setExpensesState(getExpenses());
    setBusinessName(getSettings().businessName);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const setProducts = (p: Product[]) => { setProductsState(p); saveProducts(p); };
  const setSales = (s: Sale[]) => { setSalesState(s); saveSales(s); };
  const setPurchases = (p: Purchase[]) => { setPurchasesState(p); savePurchases(p); };
  const setCustomers = (c: Customer[]) => { setCustomersState(c); saveCustomers(c); };
  const setExpensesData = (e: Expense[]) => { setExpensesState(e); saveExpenses(e); };

  const pageTitles: Record<ActivePage, string> = {
    dashboard: 'لوحة التحكم',
    products: 'المنتجات',
    inventory: 'جرد المستودع',
    sales: 'المبيعات',
    purchases: 'المشتريات',
    profits: 'الأرباح والتقارير',
    debts: 'المبالغ المستحقة',
    expenses: 'المصروفات',
    settings: 'الإعدادات',
  };

  const pageIcons: Record<ActivePage, string> = {
    dashboard: '📊',
    products: '📦',
    inventory: '🏭',
    sales: '🛒',
    purchases: '🚛',
    profits: '💰',
    debts: '💳',
    expenses: '📝',
    settings: '⚙️',
  };

  function renderPage() {
    switch (activePage) {
      case 'dashboard':
        return <Dashboard products={products} sales={sales} purchases={purchases} customers={customers} expenses={expenses} setActivePage={setActivePage} />;
      case 'products':
        return <Products products={products} setProducts={setProducts} />;
      case 'inventory':
        return <Inventory products={products} />;
      case 'sales':
        return <Sales products={products} setProducts={setProducts} sales={sales} setSales={setSales} customers={customers} setCustomers={setCustomers} />;
      case 'purchases':
        return <Purchases products={products} setProducts={setProducts} purchases={purchases} setPurchases={setPurchases} />;
      case 'profits':
        return <Profits sales={sales} purchases={purchases} expenses={expenses} />;
      case 'debts':
        return <Debts customers={customers} setCustomers={setCustomers} />;
      case 'expenses':
        return <Expenses expenses={expenses} setExpenses={setExpensesData} />;
      case 'settings':
        return <SettingsPage onDataChange={loadData} />;
      default:
        return <Dashboard products={products} sales={sales} purchases={purchases} customers={customers} expenses={expenses} setActivePage={setActivePage} />;
    }
  }

  return (
    <div className="flex h-screen bg-gray-100 overflow-hidden" dir="rtl">
      {/* Sidebar */}
      <Sidebar
        activePage={activePage}
        setActivePage={setActivePage}
        isOpen={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
        businessName={businessName}
      />

      {/* Main Content */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Title Bar - Desktop App Style */}
        <header className="no-print bg-white border-b border-gray-200 px-4 py-2.5 flex items-center justify-between flex-shrink-0 shadow-sm">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setSidebarOpen(!sidebarOpen)}
              className="lg:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
            >
              {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div className="flex items-center gap-2">
              <span className="text-lg">{pageIcons[activePage]}</span>
              <h1 className="text-base font-bold text-gray-800">{pageTitles[activePage]}</h1>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="hidden sm:flex items-center gap-2 text-xs text-gray-400 bg-gray-50 px-3 py-1.5 rounded-lg border border-gray-100">
              <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />
              متصل · البيانات محفوظة
            </div>
            <div className="text-xs text-gray-400 hidden md:block">
              {new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </header>

        {/* Page Content */}
        <div className="flex-1 overflow-y-auto p-3 sm:p-5 lg:p-6 bg-gradient-to-br from-gray-50 to-gray-100">
          <div className="animate-fade-in">
            {renderPage()}
          </div>
        </div>

        {/* Status Bar */}
        <footer className="no-print bg-gray-800 text-gray-400 px-4 py-1 flex items-center justify-between text-[11px] flex-shrink-0">
          <div className="flex items-center gap-4">
            <span>📦 {products.length} منتج</span>
            <span>🛒 {sales.length} عملية بيع</span>
            <span>👥 {customers.length} عميل</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="text-emerald-400">● متصل</span>
            <span>{businessName} v2.0</span>
          </div>
        </footer>
      </main>
    </div>
  );
}
