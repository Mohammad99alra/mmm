import {
  LayoutDashboard, Package, Warehouse, ShoppingCart,
  TrendingUp, CreditCard, Truck, Settings, X, Receipt,
} from 'lucide-react';
import { ActivePage } from '../types';

interface SidebarProps {
  activePage: ActivePage;
  setActivePage: (page: ActivePage) => void;
  isOpen: boolean;
  onClose: () => void;
  businessName: string;
}

const menuItems: { id: ActivePage; label: string; icon: React.ReactNode; group?: string }[] = [
  { id: 'dashboard', label: 'لوحة التحكم', icon: <LayoutDashboard size={19} />, group: 'رئيسي' },
  { id: 'products', label: 'المنتجات', icon: <Package size={19} />, group: 'المخزون' },
  { id: 'inventory', label: 'جرد المستودع', icon: <Warehouse size={19} /> },
  { id: 'sales', label: 'المبيعات', icon: <ShoppingCart size={19} />, group: 'العمليات' },
  { id: 'purchases', label: 'المشتريات', icon: <Truck size={19} /> },
  { id: 'expenses', label: 'المصروفات', icon: <Receipt size={19} /> },
  { id: 'profits', label: 'الأرباح', icon: <TrendingUp size={19} />, group: 'التقارير' },
  { id: 'debts', label: 'الديون المستحقة', icon: <CreditCard size={19} /> },
  { id: 'settings', label: 'الإعدادات', icon: <Settings size={19} />, group: 'النظام' },
];

export function Sidebar({ activePage, setActivePage, isOpen, onClose, businessName }: SidebarProps) {
  let lastGroup = '';

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/40 z-40 lg:hidden backdrop-blur-sm" onClick={onClose} />
      )}

      <aside
        className={`fixed top-0 right-0 h-full w-64 bg-gradient-to-b from-slate-900 via-slate-850 to-slate-900 text-white z-50 transform transition-transform duration-300 lg:translate-x-0 ${
          isOpen ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'
        } lg:sticky lg:top-0 lg:h-screen flex flex-col`}
      >
        {/* Logo/Brand */}
        <div className="p-4 border-b border-slate-700/50 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-gradient-to-br from-emerald-400 to-cyan-500 rounded-lg flex items-center justify-center shadow-lg shadow-emerald-500/20">
                <LayoutDashboard size={18} className="text-white" />
              </div>
              <div>
                <h1 className="text-sm font-bold leading-tight">{businessName}</h1>
                <p className="text-[10px] text-slate-400">نظام محاسبة متكامل</p>
              </div>
            </div>
            <button onClick={onClose} className="lg:hidden text-slate-400 hover:text-white p-1">
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Menu */}
        <nav className="flex-1 overflow-y-auto p-3 space-y-0.5">
          {menuItems.map((item) => {
            const showGroup = item.group && item.group !== lastGroup;
            if (item.group) lastGroup = item.group;

            return (
              <div key={item.id}>
                {showGroup && (
                  <div className="text-[10px] uppercase text-slate-500 font-bold tracking-wider mt-4 mb-2 px-3">
                    {item.group}
                  </div>
                )}
                <button
                  onClick={() => { setActivePage(item.id); onClose(); }}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-[13px] font-medium transition-all duration-150 ${
                    activePage === item.id
                      ? 'bg-gradient-to-l from-emerald-500/20 to-cyan-500/10 text-emerald-400 border-r-2 border-emerald-400'
                      : 'text-slate-300 hover:bg-slate-700/40 hover:text-white'
                  }`}
                >
                  <span className={activePage === item.id ? 'text-emerald-400' : 'text-slate-500'}>
                    {item.icon}
                  </span>
                  {item.label}
                </button>
              </div>
            );
          })}
        </nav>

        {/* Footer */}
        <div className="p-3 border-t border-slate-700/50 flex-shrink-0">
          <div className="text-center text-[10px] text-slate-600">
            نظام المحاسبة المتكامل v2.0
          </div>
        </div>
      </aside>
    </>
  );
}
