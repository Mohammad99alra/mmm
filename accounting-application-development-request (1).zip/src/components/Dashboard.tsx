import {
  Package, ShoppingCart, TrendingUp, CreditCard,
  AlertTriangle, ArrowUpRight, ArrowDownRight, DollarSign, Wallet, Receipt,
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { Product, Sale, Purchase, Customer, Expense, ActivePage } from '../types';
import { formatCurrency } from '../store';

interface DashboardProps {
  products: Product[];
  sales: Sale[];
  purchases: Purchase[];
  customers: Customer[];
  expenses: Expense[];
  setActivePage: (page: ActivePage) => void;
}

export function Dashboard({ products, sales, purchases, customers, expenses, setActivePage }: DashboardProps) {
  const totalProducts = products.length;
  const totalStock = products.reduce((sum, p) => sum + p.quantity, 0);
  const stockValue = products.reduce((sum, p) => sum + p.quantity * p.buyPrice, 0);
  const totalSales = sales.reduce((sum, s) => sum + s.totalPrice, 0);
  const totalPurchasesAmount = purchases.reduce((sum, p) => sum + p.totalPrice, 0);
  const totalProfit = sales.reduce((sum, s) => sum + s.profit, 0);
  const totalDebts = customers.reduce((sum, c) => sum + c.totalOwed, 0);
  const totalExpenses = expenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = totalProfit - totalExpenses;
  const lowStockProducts = products.filter((p) => p.quantity <= p.minQuantity);

  const today = new Date().toISOString().split('T')[0];
  const todaySales = sales.filter((s) => s.date === today);
  const todayRevenue = todaySales.reduce((sum, s) => sum + s.totalPrice, 0);
  const todayProfit = todaySales.reduce((sum, s) => sum + s.profit, 0);

  // Sales by month
  const monthlyData: Record<string, { sales: number; purchases: number; profit: number }> = {};
  sales.forEach((s) => {
    const month = s.date.substring(0, 7);
    if (!monthlyData[month]) monthlyData[month] = { sales: 0, purchases: 0, profit: 0 };
    monthlyData[month].sales += s.totalPrice;
    monthlyData[month].profit += s.profit;
  });
  purchases.forEach((p) => {
    const month = p.date.substring(0, 7);
    if (!monthlyData[month]) monthlyData[month] = { sales: 0, purchases: 0, profit: 0 };
    monthlyData[month].purchases += p.totalPrice;
  });

  const chartData = Object.entries(monthlyData)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-6)
    .map(([month, data]) => ({
      name: new Date(month + '-01').toLocaleDateString('ar-SA', { month: 'short' }),
      المبيعات: data.sales,
      المشتريات: data.purchases,
      الأرباح: data.profit,
    }));

  const categoryData: Record<string, number> = {};
  products.forEach((p) => {
    const cat = p.category || 'غير مصنف';
    categoryData[cat] = (categoryData[cat] || 0) + p.quantity;
  });
  const pieData = Object.entries(categoryData).map(([name, value]) => ({ name, value }));
  const COLORS = ['#10b981', '#06b6d4', '#8b5cf6', '#f59e0b', '#ef4444', '#ec4899', '#6366f1'];

  return (
    <div className="space-y-5">
      {/* Quick Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { title: 'المبيعات', value: formatCurrency(totalSales), sub: `اليوم: ${formatCurrency(todayRevenue)}`, icon: <ShoppingCart size={20} />, grad: 'from-emerald-500 to-emerald-600', onClick: () => setActivePage('sales') },
          { title: 'صافي الربح', value: formatCurrency(netProfit), sub: `ربح اليوم: ${formatCurrency(todayProfit)}`, icon: <TrendingUp size={20} />, grad: 'from-purple-500 to-purple-600', onClick: () => setActivePage('profits') },
          { title: 'المبالغ المستحقة', value: formatCurrency(totalDebts), sub: `${customers.filter(c => c.totalOwed > 0).length} عميل مدين`, icon: <CreditCard size={20} />, grad: 'from-amber-500 to-orange-500', onClick: () => setActivePage('debts') },
          { title: 'المصروفات', value: formatCurrency(totalExpenses), sub: `${expenses.length} مصروف`, icon: <Receipt size={20} />, grad: 'from-rose-500 to-pink-500', onClick: () => setActivePage('expenses') },
        ].map((stat, i) => (
          <div key={i} onClick={stat.onClick} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100 hover:shadow-md transition-all cursor-pointer group">
            <div className="flex items-start justify-between">
              <div className="flex-1 min-w-0">
                <p className="text-xs text-gray-500 font-medium">{stat.title}</p>
                <p className="text-lg font-bold text-gray-800 mt-1 truncate">{stat.value}</p>
                <p className="text-[11px] text-gray-400 mt-0.5">{stat.sub}</p>
              </div>
              <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${stat.grad} flex items-center justify-center text-white shadow-md group-hover:scale-110 transition-transform`}>
                {stat.icon}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 flex items-center gap-3 cursor-pointer hover:shadow-md" onClick={() => setActivePage('products')}>
          <div className="w-9 h-9 bg-blue-50 rounded-lg flex items-center justify-center"><Package size={18} className="text-blue-500" /></div>
          <div><p className="text-[11px] text-gray-500">المنتجات</p><p className="text-sm font-bold text-gray-800">{totalProducts}</p></div>
        </div>
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 flex items-center gap-3 cursor-pointer hover:shadow-md" onClick={() => setActivePage('inventory')}>
          <div className="w-9 h-9 bg-green-50 rounded-lg flex items-center justify-center"><ArrowUpRight size={18} className="text-green-500" /></div>
          <div><p className="text-[11px] text-gray-500">وحدات المخزون</p><p className="text-sm font-bold text-gray-800">{totalStock.toLocaleString('ar-SA')}</p></div>
        </div>
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 flex items-center gap-3">
          <div className="w-9 h-9 bg-red-50 rounded-lg flex items-center justify-center"><ArrowDownRight size={18} className="text-red-500" /></div>
          <div><p className="text-[11px] text-gray-500">المشتريات</p><p className="text-sm font-bold text-gray-800">{formatCurrency(totalPurchasesAmount)}</p></div>
        </div>
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100 flex items-center gap-3">
          <div className="w-9 h-9 bg-purple-50 rounded-lg flex items-center justify-center"><Wallet size={18} className="text-purple-500" /></div>
          <div><p className="text-[11px] text-gray-500">قيمة المخزون</p><p className="text-sm font-bold text-gray-800">{formatCurrency(stockValue)}</p></div>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <h3 className="text-sm font-bold text-gray-800 mb-3">📊 المبيعات والمشتريات الشهرية</h3>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '11px' }} />
                <Bar dataKey="المبيعات" fill="#10b981" radius={[4, 4, 0, 0]} />
                <Bar dataKey="المشتريات" fill="#06b6d4" radius={[4, 4, 0, 0]} />
                <Bar dataKey="الأرباح" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[260px] text-gray-400 text-sm">
              لا توجد بيانات بعد
            </div>
          )}
        </div>

        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <h3 className="text-sm font-bold text-gray-800 mb-3">📦 توزيع المخزون</h3>
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={85} paddingAngle={3} dataKey="value"
                  label={({ name, percent }) => `${name} ${((percent ?? 0) * 100).toFixed(0)}%`}
                >
                  {pieData.map((_entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[260px] text-gray-400 text-sm">لا توجد منتجات</div>
          )}
        </div>
      </div>

      {/* Bottom Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Low Stock */}
        {lowStockProducts.length > 0 && (
          <div className="bg-gradient-to-r from-red-50 to-orange-50 rounded-xl p-4 border border-red-200">
            <div className="flex items-center gap-2 mb-3">
              <AlertTriangle size={16} className="text-red-500" />
              <h3 className="text-sm font-bold text-red-700">⚠️ منتجات منخفضة المخزون ({lowStockProducts.length})</h3>
            </div>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {lowStockProducts.map((p) => (
                <div key={p.id} className="bg-white rounded-lg p-2.5 border border-red-100 flex items-center justify-between">
                  <div>
                    <p className="font-medium text-gray-800 text-xs">{p.name}</p>
                    <p className="text-[10px] text-gray-500">{p.category}</p>
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold text-red-600">{p.quantity} {p.unit}</p>
                    <p className="text-[10px] text-gray-400">حد أدنى: {p.minQuantity}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Recent Sales */}
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-sm font-bold text-gray-800">🛒 آخر المبيعات</h3>
            <button onClick={() => setActivePage('sales')} className="text-xs text-emerald-500 hover:underline">عرض الكل</button>
          </div>
          {sales.length > 0 ? (
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {sales.slice(-5).reverse().map((s) => (
                <div key={s.id} className="flex items-center justify-between p-2.5 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-emerald-100 rounded-lg flex items-center justify-center">
                      <DollarSign size={14} className="text-emerald-600" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-gray-800">{s.productName}</p>
                      <p className="text-[10px] text-gray-400">{s.customerName || 'نقدي'} · {s.quantity}×</p>
                    </div>
                  </div>
                  <div className="text-left">
                    <p className="text-xs font-bold text-gray-800">{formatCurrency(s.totalPrice)}</p>
                    <p className="text-[10px] text-emerald-500">+{formatCurrency(s.profit)}</p>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-gray-400 py-6 text-xs">لا توجد مبيعات بعد</p>
          )}
        </div>

        {/* Low stock placeholder if no low stock */}
        {lowStockProducts.length === 0 && (
          <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
            <h3 className="text-sm font-bold text-gray-800 mb-3">💰 ملخص مالي</h3>
            <div className="space-y-3">
              <div className="flex justify-between items-center p-2 bg-green-50 rounded-lg">
                <span className="text-xs text-gray-600">إجمالي المبيعات</span>
                <span className="text-xs font-bold text-green-600">{formatCurrency(totalSales)}</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-blue-50 rounded-lg">
                <span className="text-xs text-gray-600">إجمالي المشتريات</span>
                <span className="text-xs font-bold text-blue-600">{formatCurrency(totalPurchasesAmount)}</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-rose-50 rounded-lg">
                <span className="text-xs text-gray-600">إجمالي المصروفات</span>
                <span className="text-xs font-bold text-rose-600">{formatCurrency(totalExpenses)}</span>
              </div>
              <div className="flex justify-between items-center p-2 bg-purple-50 rounded-lg border-2 border-purple-200">
                <span className="text-xs font-bold text-gray-700">صافي الربح</span>
                <span className={`text-sm font-bold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(netProfit)}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
