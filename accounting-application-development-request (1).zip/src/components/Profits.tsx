import { useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, Calendar, Receipt, Printer } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Sale, Purchase, Expense } from '../types';
import { formatCurrency } from '../store';

interface ProfitsProps {
  sales: Sale[];
  purchases: Purchase[];
  expenses: Expense[];
}

export function Profits({ sales, purchases, expenses }: ProfitsProps) {
  const [period, setPeriod] = useState<'day' | 'week' | 'month' | 'year' | 'all'>('month');

  const now = new Date();
  const filterDate = (dateStr: string) => {
    const date = new Date(dateStr);
    switch (period) {
      case 'day': return date >= new Date(now.getFullYear(), now.getMonth(), now.getDate());
      case 'week': return date >= new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      case 'month': return date >= new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
      case 'year': return date >= new Date(now.getFullYear() - 1, now.getMonth(), now.getDate());
      default: return true;
    }
  };

  const filteredSales = sales.filter((s) => filterDate(s.date));
  const filteredPurchases = purchases.filter((p) => filterDate(p.date));
  const filteredExpenses = expenses.filter((e) => filterDate(e.date));

  const totalRevenue = filteredSales.reduce((sum, s) => sum + s.totalPrice, 0);
  const totalCost = filteredSales.reduce((sum, s) => sum + s.buyPrice * s.quantity, 0);
  const totalPurchases = filteredPurchases.reduce((sum, p) => sum + p.totalPrice, 0);
  const grossProfit = filteredSales.reduce((sum, s) => sum + s.profit, 0);
  const totalExpenseAmount = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);
  const netProfit = grossProfit - totalExpenseAmount;
  const profitMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
  const netMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  // Daily profit data
  const dailyData: Record<string, { revenue: number; cost: number; profit: number; expenses: number; sales: number }> = {};
  filteredSales.forEach((s) => {
    if (!dailyData[s.date]) dailyData[s.date] = { revenue: 0, cost: 0, profit: 0, expenses: 0, sales: 0 };
    dailyData[s.date].revenue += s.totalPrice;
    dailyData[s.date].cost += s.buyPrice * s.quantity;
    dailyData[s.date].profit += s.profit;
    dailyData[s.date].sales += 1;
  });
  filteredExpenses.forEach((e) => {
    if (!dailyData[e.date]) dailyData[e.date] = { revenue: 0, cost: 0, profit: 0, expenses: 0, sales: 0 };
    dailyData[e.date].expenses += e.amount;
  });

  const chartData = Object.entries(dailyData)
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([date, data]) => ({
      name: new Date(date).toLocaleDateString('ar-SA', { month: 'short', day: 'numeric' }),
      الإيرادات: data.revenue,
      الربح: data.profit,
      المصروفات: data.expenses,
      الصافي: data.profit - data.expenses,
    }));

  // Product profits
  const productProfits: Record<string, { name: string; profit: number; revenue: number; qty: number }> = {};
  filteredSales.forEach((s) => {
    if (!productProfits[s.productId]) productProfits[s.productId] = { name: s.productName, profit: 0, revenue: 0, qty: 0 };
    productProfits[s.productId].profit += s.profit;
    productProfits[s.productId].revenue += s.totalPrice;
    productProfits[s.productId].qty += s.quantity;
  });

  const topProducts = Object.values(productProfits).sort((a, b) => b.profit - a.profit).slice(0, 10);

  const periods = [
    { key: 'day' as const, label: 'اليوم' },
    { key: 'week' as const, label: 'أسبوع' },
    { key: 'month' as const, label: 'شهر' },
    { key: 'year' as const, label: 'سنة' },
    { key: 'all' as const, label: 'الكل' },
  ];

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">الأرباح والتقارير المالية</h2>
          <p className="text-gray-500 text-xs mt-0.5">تحليل شامل للأداء المالي</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex bg-gray-100 rounded-lg p-0.5">
            {periods.map((p) => (
              <button
                key={p.key}
                onClick={() => setPeriod(p.key)}
                className={`px-3 py-1.5 rounded-md text-xs font-medium transition-all ${
                  period === p.key ? 'bg-white text-purple-600 shadow-sm' : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {p.label}
              </button>
            ))}
          </div>
          <button onClick={() => window.print()} className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg no-print">
            <Printer size={16} />
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-1.5 mb-1"><DollarSign size={16} /><span className="text-xs opacity-90">الإيرادات</span></div>
          <p className="text-lg font-bold">{formatCurrency(totalRevenue)}</p>
          <p className="text-[10px] opacity-75 mt-0.5">{filteredSales.length} عملية بيع</p>
        </div>
        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-1.5 mb-1"><TrendingDown size={16} /><span className="text-xs opacity-90">التكاليف</span></div>
          <p className="text-lg font-bold">{formatCurrency(totalCost)}</p>
          <p className="text-[10px] opacity-75 mt-0.5">مشتريات: {formatCurrency(totalPurchases)}</p>
        </div>
        <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-1.5 mb-1"><TrendingUp size={16} /><span className="text-xs opacity-90">الربح الإجمالي</span></div>
          <p className="text-lg font-bold">{formatCurrency(grossProfit)}</p>
          <p className="text-[10px] opacity-75 mt-0.5">هامش: {profitMargin.toFixed(1)}%</p>
        </div>
        <div className="bg-gradient-to-br from-rose-500 to-pink-500 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-1.5 mb-1"><Receipt size={16} /><span className="text-xs opacity-90">المصروفات</span></div>
          <p className="text-lg font-bold">{formatCurrency(totalExpenseAmount)}</p>
          <p className="text-[10px] opacity-75 mt-0.5">{filteredExpenses.length} مصروف</p>
        </div>
        <div className={`bg-gradient-to-br ${netProfit >= 0 ? 'from-green-600 to-emerald-700' : 'from-red-500 to-red-600'} rounded-xl p-4 text-white shadow-lg`}>
          <div className="flex items-center gap-1.5 mb-1"><Calendar size={16} /><span className="text-xs opacity-90">صافي الربح</span></div>
          <p className="text-lg font-bold">{formatCurrency(netProfit)}</p>
          <p className="text-[10px] opacity-75 mt-0.5">هامش صافي: {netMargin.toFixed(1)}%</p>
        </div>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <h3 className="text-sm font-bold text-gray-800 mb-3">📊 الإيرادات والأرباح</h3>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '11px' }} />
                <Bar dataKey="الإيرادات" fill="#10b981" radius={[3, 3, 0, 0]} />
                <Bar dataKey="الربح" fill="#8b5cf6" radius={[3, 3, 0, 0]} />
                <Bar dataKey="المصروفات" fill="#f43f5e" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[250px] text-gray-400 text-sm">لا توجد بيانات</div>
          )}
        </div>

        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <h3 className="text-sm font-bold text-gray-800 mb-3">📈 تطور صافي الأرباح</h3>
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <AreaChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                <YAxis tick={{ fontSize: 10 }} />
                <Tooltip contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', fontSize: '11px' }} />
                <Area type="monotone" dataKey="الصافي" stroke="#8b5cf6" fill="#8b5cf620" strokeWidth={2} />
                <Area type="monotone" dataKey="الإيرادات" stroke="#10b981" fill="#10b98110" strokeWidth={1.5} />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            <div className="flex items-center justify-center h-[250px] text-gray-400 text-sm">لا توجد بيانات</div>
          )}
        </div>
      </div>

      {/* Profit & Loss Statement */}
      <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
        <h3 className="text-sm font-bold text-gray-800 mb-3">📋 قائمة الدخل (بيان الأرباح والخسائر)</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center p-2.5 bg-green-50 rounded-lg">
            <span className="text-xs font-medium text-gray-700">إيرادات المبيعات</span>
            <span className="text-xs font-bold text-green-600">{formatCurrency(totalRevenue)}</span>
          </div>
          <div className="flex justify-between items-center p-2.5 bg-blue-50 rounded-lg">
            <span className="text-xs font-medium text-gray-700">(-) تكلفة البضاعة المباعة</span>
            <span className="text-xs font-bold text-blue-600">{formatCurrency(totalCost)}</span>
          </div>
          <div className="flex justify-between items-center p-2.5 bg-purple-50 rounded-lg border border-purple-200">
            <span className="text-xs font-bold text-gray-800">= إجمالي الربح</span>
            <span className={`text-sm font-bold ${grossProfit >= 0 ? 'text-purple-600' : 'text-red-600'}`}>{formatCurrency(grossProfit)}</span>
          </div>
          <div className="flex justify-between items-center p-2.5 bg-rose-50 rounded-lg">
            <span className="text-xs font-medium text-gray-700">(-) المصروفات التشغيلية</span>
            <span className="text-xs font-bold text-rose-600">{formatCurrency(totalExpenseAmount)}</span>
          </div>
          <div className={`flex justify-between items-center p-3 rounded-lg border-2 ${netProfit >= 0 ? 'bg-green-50 border-green-300' : 'bg-red-50 border-red-300'}`}>
            <span className="text-sm font-bold text-gray-800">= صافي الربح</span>
            <span className={`text-lg font-bold ${netProfit >= 0 ? 'text-green-600' : 'text-red-600'}`}>{formatCurrency(netProfit)}</span>
          </div>
        </div>
      </div>

      {/* Top Products */}
      <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
        <h3 className="text-sm font-bold text-gray-800 mb-3">🏆 أكثر المنتجات ربحية</h3>
        {topProducts.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-right py-2.5 px-3 text-gray-600 font-semibold">#</th>
                  <th className="text-right py-2.5 px-3 text-gray-600 font-semibold">المنتج</th>
                  <th className="text-right py-2.5 px-3 text-gray-600 font-semibold">الكمية</th>
                  <th className="text-right py-2.5 px-3 text-gray-600 font-semibold">الإيرادات</th>
                  <th className="text-right py-2.5 px-3 text-gray-600 font-semibold">الربح</th>
                  <th className="text-right py-2.5 px-3 text-gray-600 font-semibold">الهامش</th>
                </tr>
              </thead>
              <tbody>
                {topProducts.map((p, i) => (
                  <tr key={i} className="border-t border-gray-50 hover:bg-gray-50/50">
                    <td className="py-2 px-3">
                      <span className={`w-6 h-6 rounded flex items-center justify-center text-[10px] font-bold ${
                        i === 0 ? 'bg-yellow-100 text-yellow-700' : i === 1 ? 'bg-gray-100 text-gray-700' : i === 2 ? 'bg-amber-100 text-amber-700' : 'bg-gray-50 text-gray-500'
                      }`}>{i + 1}</span>
                    </td>
                    <td className="py-2 px-3 font-medium text-gray-800">{p.name}</td>
                    <td className="py-2 px-3 text-gray-600">{p.qty}</td>
                    <td className="py-2 px-3 text-gray-600">{formatCurrency(p.revenue)}</td>
                    <td className="py-2 px-3 font-bold text-emerald-600">{formatCurrency(p.profit)}</td>
                    <td className="py-2 px-3">
                      <span className="px-1.5 py-0.5 bg-purple-50 text-purple-700 rounded text-[10px] font-medium">
                        {p.revenue > 0 ? ((p.profit / p.revenue) * 100).toFixed(1) : 0}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <p className="text-center text-gray-400 py-6 text-xs">لا توجد بيانات</p>
        )}
      </div>
    </div>
  );
}
