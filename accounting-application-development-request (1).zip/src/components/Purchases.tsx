import { useState } from 'react';
import { Plus, Search, Truck, Trash2 } from 'lucide-react';
import { Product, Purchase } from '../types';
import { generateId, formatCurrency, formatDate, getTodayStr } from '../store';

interface PurchasesProps {
  products: Product[];
  setProducts: (products: Product[]) => void;
  purchases: Purchase[];
  setPurchases: (purchases: Purchase[]) => void;
}

export function Purchases({ products, setProducts, purchases, setPurchases }: PurchasesProps) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [form, setForm] = useState({ productId: '', quantity: 1, unitPrice: 0, supplierName: '', isPaid: true, date: getTodayStr() });

  const filtered = purchases.filter((p) => p.productName.includes(search) || p.supplierName.includes(search));
  const totalPurchases = filtered.reduce((sum, p) => sum + p.totalPrice, 0);

  function handleProductChange(productId: string) {
    const product = products.find((p) => p.id === productId);
    setForm({ ...form, productId, unitPrice: product ? product.buyPrice : 0 });
  }

  function handleSave() {
    if (!form.productId || form.quantity <= 0) return;
    const product = products.find((p) => p.id === form.productId);
    if (!product) return;
    const purchase: Purchase = {
      id: generateId(), productId: product.id, productName: product.name,
      quantity: form.quantity, unitPrice: form.unitPrice, supplierName: form.supplierName,
      isPaid: form.isPaid, totalPrice: form.quantity * form.unitPrice, date: form.date,
    };
    setPurchases([...purchases, purchase]);
    setProducts(products.map((p) => p.id === product.id ? { ...p, quantity: p.quantity + form.quantity, buyPrice: form.unitPrice } : p));
    setShowForm(false);
    setForm({ productId: '', quantity: 1, unitPrice: 0, supplierName: '', isPaid: true, date: getTodayStr() });
  }

  function handleDelete(id: string) {
    if (confirm('حذف هذه العملية؟')) {
      const purchase = purchases.find((p) => p.id === id);
      if (purchase) setProducts(products.map((p) => p.id === purchase.productId ? { ...p, quantity: Math.max(0, p.quantity - purchase.quantity) } : p));
      setPurchases(purchases.filter((p) => p.id !== id));
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">المشتريات</h2>
          <p className="text-gray-500 text-xs mt-0.5">تسجيل عمليات الشراء</p>
        </div>
        <button onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-gradient-to-l from-blue-500 to-indigo-500 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-lg shadow-blue-200">
          <Plus size={16} /> عملية شراء
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
          <p className="text-[10px] text-gray-500">عدد العمليات</p><p className="text-lg font-bold text-gray-800">{filtered.length}</p>
        </div>
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
          <p className="text-[10px] text-gray-500">إجمالي المشتريات</p><p className="text-lg font-bold text-blue-600">{formatCurrency(totalPurchases)}</p>
        </div>
      </div>

      <div className="relative">
        <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input type="text" placeholder="بحث..." value={search} onChange={(e) => setSearch(e.target.value)}
          className="w-full pr-9 pl-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-blue-500/30 text-sm" />
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-xl p-5 w-full max-w-lg shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-gray-800 mb-4">عملية شراء جديدة</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">المنتج *</label>
                <select value={form.productId} onChange={(e) => handleProductChange(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm">
                  <option value="">اختر المنتج</option>
                  {products.map((p) => <option key={p.id} value={p.id}>{p.name} (المخزون: {p.quantity})</option>)}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">الكمية *</label>
                  <input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" min="1" />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">سعر الشراء</label>
                  <input type="number" value={form.unitPrice} onChange={(e) => setForm({ ...form, unitPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" min="0" step="0.01" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">المورد</label>
                <input type="text" value={form.supplierName} onChange={(e) => setForm({ ...form, supplierName: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" placeholder="اختياري" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">التاريخ</label>
                <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" />
              </div>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" checked={form.isPaid} onChange={() => setForm({ ...form, isPaid: true })} className="w-4 h-4" /><span className="text-sm">مدفوع</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" checked={!form.isPaid} onChange={() => setForm({ ...form, isPaid: false })} className="w-4 h-4" /><span className="text-sm">آجل</span>
                </label>
              </div>
              <div className="p-3 bg-gray-50 rounded-lg text-xs">
                <div className="flex justify-between"><span className="text-gray-500">الإجمالي:</span><span className="font-bold">{formatCurrency(form.quantity * form.unitPrice)}</span></div>
              </div>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={handleSave} className="flex-1 bg-gradient-to-l from-blue-500 to-indigo-500 text-white py-2 rounded-lg text-sm font-medium shadow-lg">تسجيل الشراء</button>
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">التاريخ</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">المنتج</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">المورد</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الكمية</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">السعر</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الإجمالي</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الحالة</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">حذف</th>
                </tr>
              </thead>
              <tbody>
                {[...filtered].reverse().map((p) => (
                  <tr key={p.id} className="border-t border-gray-50 hover:bg-gray-50/50">
                    <td className="py-2.5 px-3 text-gray-500 text-[11px]">{formatDate(p.date)}</td>
                    <td className="py-2.5 px-3 font-medium text-gray-800">{p.productName}</td>
                    <td className="py-2.5 px-3 text-gray-600">{p.supplierName || '-'}</td>
                    <td className="py-2.5 px-3 text-gray-600">{p.quantity}</td>
                    <td className="py-2.5 px-3 text-gray-600">{formatCurrency(p.unitPrice)}</td>
                    <td className="py-2.5 px-3 font-medium text-gray-800">{formatCurrency(p.totalPrice)}</td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${p.isPaid ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {p.isPaid ? 'مدفوع' : 'آجل'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <button onClick={() => handleDelete(p.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded"><Trash2 size={14} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-gray-400">
            <Truck size={40} className="mx-auto mb-3 text-gray-300" />
            <p className="font-medium">لا توجد مشتريات</p>
          </div>
        )}
      </div>
    </div>
  );
}
