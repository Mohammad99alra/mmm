import { useState } from 'react';
import { Plus, Edit2, Trash2, Search, Package } from 'lucide-react';
import { Product } from '../types';
import { generateId, formatCurrency, getTodayStr } from '../store';

interface ProductsProps {
  products: Product[];
  setProducts: (products: Product[]) => void;
}

const emptyProduct = (): Partial<Product> => ({
  name: '', category: '', buyPrice: 0, sellPrice: 0, quantity: 0, minQuantity: 5, unit: 'قطعة', barcode: '',
});

export function Products({ products, setProducts }: ProductsProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<Product>>(emptyProduct());
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('');

  const categories = [...new Set(products.map((p) => p.category).filter(Boolean))];
  const filtered = products.filter((p) => {
    const matchesSearch = p.name.includes(search) || p.category.includes(search) || (p.barcode || '').includes(search);
    const matchesCategory = !filterCategory || p.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  function handleSave() {
    if (!form.name || !form.buyPrice || !form.sellPrice) return;
    if (editingId) {
      setProducts(products.map((p) => p.id === editingId ? { ...p, ...form } as Product : p));
    } else {
      const newProduct: Product = {
        id: generateId(), name: form.name!, category: form.category || 'عام',
        buyPrice: form.buyPrice!, sellPrice: form.sellPrice!, quantity: form.quantity || 0,
        minQuantity: form.minQuantity || 5, unit: form.unit || 'قطعة', barcode: form.barcode || '',
        createdAt: getTodayStr(),
      };
      setProducts([...products, newProduct]);
    }
    resetForm();
  }

  function resetForm() {
    setShowForm(false);
    setEditingId(null);
    setForm(emptyProduct());
  }

  function handleEdit(product: Product) {
    setForm(product);
    setEditingId(product.id);
    setShowForm(true);
  }

  function handleDelete(id: string) {
    if (confirm('هل أنت متأكد من حذف هذا المنتج؟')) {
      setProducts(products.filter((p) => p.id !== id));
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">إدارة المنتجات</h2>
          <p className="text-gray-500 text-xs mt-0.5">{products.length} منتج مسجل</p>
        </div>
        <button
          onClick={() => { setForm(emptyProduct()); setEditingId(null); setShowForm(true); }}
          className="flex items-center gap-2 bg-gradient-to-l from-emerald-500 to-cyan-500 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-lg shadow-emerald-200 hover:shadow-xl transition-all"
        >
          <Plus size={16} />
          إضافة منتج
        </button>
      </div>

      {/* Search */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="text" placeholder="بحث عن منتج أو باركود..." value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-400 text-sm" />
        </div>
        <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)}
          className="px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 bg-white text-sm">
          <option value="">كل الأصناف</option>
          {categories.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={resetForm}>
          <div className="bg-white rounded-xl p-5 w-full max-w-lg shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-gray-800 mb-4">
              {editingId ? 'تعديل المنتج' : 'إضافة منتج جديد'}
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-600 mb-1">اسم المنتج *</label>
                <input type="text" value={form.name || ''} onChange={(e) => setForm({ ...form, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" placeholder="اسم المنتج" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">الصنف</label>
                <input type="text" value={form.category || ''} onChange={(e) => setForm({ ...form, category: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" placeholder="الصنف" list="categories" />
                <datalist id="categories">{categories.map((c) => <option key={c} value={c} />)}</datalist>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">الوحدة</label>
                <select value={form.unit || 'قطعة'} onChange={(e) => setForm({ ...form, unit: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 bg-white text-sm">
                  {['قطعة', 'كيلو', 'لتر', 'متر', 'علبة', 'كرتون', 'طن', 'حبة', 'درزن'].map(u => <option key={u} value={u}>{u}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">سعر الشراء *</label>
                <input type="number" value={form.buyPrice || ''} onChange={(e) => setForm({ ...form, buyPrice: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" min="0" step="0.01" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">سعر البيع *</label>
                <input type="number" value={form.sellPrice || ''} onChange={(e) => setForm({ ...form, sellPrice: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" min="0" step="0.01" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">الكمية</label>
                <input type="number" value={form.quantity || ''} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" min="0" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">الحد الأدنى</label>
                <input type="number" value={form.minQuantity || ''} onChange={(e) => setForm({ ...form, minQuantity: Number(e.target.value) })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" min="0" />
              </div>
              <div className="sm:col-span-2">
                <label className="block text-xs font-medium text-gray-600 mb-1">الباركود (اختياري)</label>
                <input type="text" value={form.barcode || ''} onChange={(e) => setForm({ ...form, barcode: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" placeholder="رقم الباركود" />
              </div>
            </div>
            {form.buyPrice && form.sellPrice ? (
              <div className="mt-3 p-2.5 bg-emerald-50 rounded-lg text-xs">
                <span className="text-gray-600">هامش الربح: </span>
                <span className="font-bold text-emerald-700">
                  {formatCurrency(form.sellPrice - form.buyPrice)} ({((form.sellPrice - form.buyPrice) / form.buyPrice * 100).toFixed(1)}%)
                </span>
              </div>
            ) : null}
            <div className="flex gap-2 mt-5">
              <button onClick={handleSave} className="flex-1 bg-gradient-to-l from-emerald-500 to-cyan-500 text-white py-2 rounded-lg text-sm font-medium shadow-lg">{editingId ? 'تحديث' : 'إضافة'}</button>
              <button onClick={resetForm} className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">المنتج</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الصنف</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">شراء</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">بيع</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الكمية</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">ربح/وحدة</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p) => (
                  <tr key={p.id} className="border-t border-gray-50 hover:bg-gray-50/50">
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 bg-gradient-to-br from-emerald-100 to-cyan-100 rounded flex items-center justify-center">
                          <Package size={13} className="text-emerald-600" />
                        </div>
                        <div>
                          <span className="font-medium text-gray-800">{p.name}</span>
                          {p.barcode && <p className="text-[10px] text-gray-400">{p.barcode}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="py-2.5 px-3"><span className="px-1.5 py-0.5 bg-gray-100 rounded text-[10px]">{p.category}</span></td>
                    <td className="py-2.5 px-3 text-gray-600">{formatCurrency(p.buyPrice)}</td>
                    <td className="py-2.5 px-3 text-gray-600">{formatCurrency(p.sellPrice)}</td>
                    <td className="py-2.5 px-3">
                      <span className={`font-medium ${p.quantity <= p.minQuantity ? 'text-red-600' : 'text-gray-800'}`}>
                        {p.quantity} {p.unit}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 font-medium text-emerald-600">{formatCurrency(p.sellPrice - p.buyPrice)}</td>
                    <td className="py-2.5 px-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => handleEdit(p)} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded"><Edit2 size={14} /></button>
                        <button onClick={() => handleDelete(p.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-gray-400">
            <Package size={40} className="mx-auto mb-3 text-gray-300" />
            <p className="font-medium">لا توجد منتجات</p>
            <p className="text-xs mt-1">ابدأ بإضافة منتجاتك</p>
          </div>
        )}
      </div>
    </div>
  );
}
