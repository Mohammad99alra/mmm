import { useState, useRef } from 'react';
import { Download, Upload, Trash2, Database, Shield, CheckCircle, Building2, Coins } from 'lucide-react';
import { exportAllData, importAllData, getSettings, saveSettings } from '../store';
import { CurrencyType } from '../types';

interface SettingsPageProps {
  onDataChange: () => void;
}

const CURRENCIES: { key: CurrencyType; label: string; symbol: string }[] = [
  { key: 'USD', label: 'دولار أمريكي', symbol: '$' },
  { key: 'SAR', label: 'ريال سعودي', symbol: 'ر.س' },
  { key: 'IQD', label: 'دينار عراقي', symbol: 'د.ع' },
  { key: 'SYP', label: 'ليرة سورية', symbol: 'ل.س' },
  { key: 'AED', label: 'درهم إماراتي', symbol: 'د.إ' },
  { key: 'EGP', label: 'جنيه مصري', symbol: 'ج.م' },
  { key: 'EUR', label: 'يورو', symbol: '€' },
];

export function SettingsPage({ onDataChange }: SettingsPageProps) {
  const settings = getSettings();
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);
  const [businessName, setBusinessName] = useState(settings.businessName);
  const [currency, setCurrency] = useState<CurrencyType>(settings.currency);
  const fileInputRef = useRef<HTMLInputElement>(null);

  function showMsg(text: string, type: 'success' | 'error') {
    setMessage({ text, type });
    setTimeout(() => setMessage(null), 3000);
  }

  function handleSaveSettings() {
    saveSettings({ businessName, currency });
    showMsg('تم حفظ الإعدادات بنجاح', 'success');
    onDataChange();
  }

  function handleExport() {
    const data = exportAllData();
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `accounting-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
    showMsg('تم تصدير البيانات بنجاح', 'success');
  }

  function handleImport(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (importAllData(result)) {
        showMsg('تم استيراد البيانات بنجاح', 'success');
        onDataChange();
      } else {
        showMsg('خطأ في الملف', 'error');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  }

  function handleClearAll() {
    if (confirm('هل أنت متأكد من حذف جميع البيانات؟')) {
      if (confirm('تأكيد نهائي: سيتم حذف كل شيء!')) {
        localStorage.clear();
        onDataChange();
        showMsg('تم حذف جميع البيانات', 'success');
      }
    }
  }

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h2 className="text-xl font-bold text-gray-800">الإعدادات</h2>
        <p className="text-gray-500 text-xs mt-0.5">إعدادات النظام والنسخ الاحتياطي</p>
      </div>

      {message && (
        <div className={`p-3 rounded-lg flex items-center gap-2 text-sm ${message.type === 'success' ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
          <CheckCircle size={16} />{message.text}
        </div>
      )}

      {/* Business Settings */}
      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-indigo-100 rounded-lg flex items-center justify-center"><Building2 size={18} className="text-indigo-600" /></div>
          <div><h3 className="text-sm font-bold text-gray-800">إعدادات النشاط</h3><p className="text-[10px] text-gray-500">اسم النشاط والعملة</p></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1">اسم النشاط التجاري</label>
            <input type="text" value={businessName} onChange={(e) => setBusinessName(e.target.value)}
              className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" placeholder="مثال: متجر السعادة" />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600 mb-1 flex items-center gap-1"><Coins size={12} /> العملة</label>
            <select value={currency} onChange={(e) => setCurrency(e.target.value as CurrencyType)}
              className="w-full px-3 py-2 rounded-lg border border-gray-200 bg-white text-sm">
              {CURRENCIES.map((c) => <option key={c.key} value={c.key}>{c.label} ({c.symbol})</option>)}
            </select>
          </div>
        </div>
        <button onClick={handleSaveSettings}
          className="bg-indigo-500 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-indigo-600 transition-colors">
          حفظ الإعدادات
        </button>
      </div>

      {/* Backup */}
      <div className="bg-white rounded-xl p-5 shadow-sm border border-gray-100 space-y-4">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-blue-100 rounded-lg flex items-center justify-center"><Database size={18} className="text-blue-600" /></div>
          <div><h3 className="text-sm font-bold text-gray-800">النسخ الاحتياطي</h3><p className="text-[10px] text-gray-500">تصدير واستيراد البيانات</p></div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Download size={16} className="text-emerald-600" />
              <span className="text-xs font-medium text-gray-700">تصدير البيانات</span>
            </div>
            <p className="text-[10px] text-gray-500 mb-2">تحميل نسخة احتياطية JSON</p>
            <button onClick={handleExport}
              className="w-full bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-medium hover:bg-emerald-600 flex items-center justify-center gap-1">
              <Download size={14} /> تصدير
            </button>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2 mb-2">
              <Upload size={16} className="text-blue-600" />
              <span className="text-xs font-medium text-gray-700">استيراد البيانات</span>
            </div>
            <p className="text-[10px] text-gray-500 mb-2">استعادة من نسخة سابقة</p>
            <input ref={fileInputRef} type="file" accept=".json" onChange={handleImport} className="hidden" />
            <button onClick={() => fileInputRef.current?.click()}
              className="w-full bg-blue-500 text-white px-3 py-1.5 rounded-lg text-xs font-medium hover:bg-blue-600 flex items-center justify-center gap-1">
              <Upload size={14} /> استيراد
            </button>
          </div>
        </div>
      </div>

      {/* Danger */}
      <div className="bg-white rounded-xl p-5 shadow-sm border border-red-200 space-y-3">
        <div className="flex items-center gap-2">
          <div className="w-9 h-9 bg-red-100 rounded-lg flex items-center justify-center"><Shield size={18} className="text-red-600" /></div>
          <div><h3 className="text-sm font-bold text-red-700">منطقة الخطر</h3><p className="text-[10px] text-gray-500">لا يمكن التراجع</p></div>
        </div>
        <button onClick={handleClearAll}
          className="bg-red-500 text-white px-4 py-2 rounded-lg text-xs font-medium hover:bg-red-600 flex items-center gap-1">
          <Trash2 size={14} /> حذف كل البيانات
        </button>
      </div>

      {/* App Info */}
      <div className="bg-gradient-to-br from-gray-800 to-gray-900 rounded-xl p-5 text-white">
        <h3 className="font-bold mb-1">نظام المحاسبة المتكامل</h3>
        <p className="text-gray-400 text-xs">الإصدار 2.0</p>
        <div className="mt-3 grid grid-cols-2 gap-1 text-xs text-gray-300">
          <p>✓ إدارة المنتجات والمخزون</p>
          <p>✓ تسجيل المبيعات والمشتريات</p>
          <p>✓ حساب الأرباح تلقائياً</p>
          <p>✓ إدارة ديون العملاء</p>
          <p>✓ المصروفات التشغيلية</p>
          <p>✓ تقارير ورسوم بيانية</p>
          <p>✓ نسخ احتياطي واستعادة</p>
          <p>✓ دعم عملات متعددة</p>
          <p>✓ يعمل بدون إنترنت</p>
          <p>✓ طباعة التقارير</p>
        </div>
      </div>
    </div>
  );
}
