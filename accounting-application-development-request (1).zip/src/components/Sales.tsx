import { useState } from 'react';
import { Plus, Search, ShoppingCart, Trash2 } from 'lucide-react';
import { Product, Sale, Customer } from '../types';
import { generateId, formatCurrency, formatDate, getTodayStr } from '../store';

interface SalesProps {
  products: Product[];
  setProducts: (products: Product[]) => void;
  sales: Sale[];
  setSales: (sales: Sale[]) => void;
  customers: Customer[];
  setCustomers: (customers: Customer[]) => void;
}

export function Sales({ products, setProducts, sales, setSales, customers, setCustomers }: SalesProps) {
  const [showForm, setShowForm] = useState(false);
  const [search, setSearch] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [form, setForm] = useState({ productId: '', quantity: 1, unitPrice: 0, customerName: '', isPaid: true, date: getTodayStr() });

  const selectedProduct = products.find((p) => p.id === form.productId);
  const filtered = sales.filter((s) => {
    const matchSearch = s.productName.includes(search) || s.customerName.includes(search);
    const matchDate = !dateFilter || s.date === dateFilter;
    return matchSearch && matchDate;
  });

  const customerNames = [...new Set(customers.map((c) => c.name))];
  const totalRevenue = filtered.reduce((sum, s) => sum + s.totalPrice, 0);
  const totalProfit = filtered.reduce((sum, s) => sum + s.profit, 0);

  function handleProductChange(productId: string) {
    const product = products.find((p) => p.id === productId);
    setForm({ ...form, productId, unitPrice: product ? product.sellPrice : 0 });
  }

  function handleSave() {
    if (!form.productId || form.quantity <= 0) return;
    const product = products.find((p) => p.id === form.productId);
    if (!product) return;
    if (product.quantity < form.quantity) { alert(`الكمية المتاحة فقط ${product.quantity} ${product.unit}`); return; }

    const totalPrice = form.quantity * form.unitPrice;
    const profit = form.quantity * (form.unitPrice - product.buyPrice);
    const sale: Sale = {
      id: generateId(), productId: product.id, productName: product.name,
      quantity: form.quantity, unitPrice: form.unitPrice, buyPrice: product.buyPrice,
      totalPrice, profit, customerName: form.customerName, isPaid: form.isPaid, date: form.date,
    };
    setSales([...sales, sale]);
    setProducts(products.map((p) => p.id === product.id ? { ...p, quantity: p.quantity - form.quantity } : p));

    if (!form.isPaid && form.customerName) {
      const existing = customers.find((c) => c.name === form.customerName);
      if (existing) {
        setCustomers(customers.map((c) => c.id === existing.id ? {
          ...c, totalOwed: c.totalOwed + totalPrice,
          transactions: [...c.transactions, { id: generateId(), type: 'sale' as const, amount: totalPrice, date: form.date, note: `شراء ${product.name} × ${form.quantity}` }],
        } : c));
      } else {
        setCustomers([...customers, {
          id: generateId(), name: form.customerName, phone: '', totalOwed: totalPrice,
          transactions: [{ id: generateId(), type: 'sale' as const, amount: totalPrice, date: form.date, note: `شراء ${product.name} × ${form.quantity}` }],
        }]);
      }
    }
    setShowForm(false);
    setForm({ productId: '', quantity: 1, unitPrice: 0, customerName: '', isPaid: true, date: getTodayStr() });
  }

  function handleDelete(id: string) {
    if (confirm('حذف هذه العملية؟')) {
      const sale = sales.find((s) => s.id === id);
      if (sale) setProducts(products.map((p) => p.id === sale.productId ? { ...p, quantity: p.quantity + sale.quantity } : p));
      setSales(sales.filter((s) => s.id !== id));
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">المبيعات</h2>
          <p className="text-gray-500 text-xs mt-0.5">تسجيل ومتابعة عمليات البيع</p>
        </div>
        <button onClick={() => setShowForm(true)}
          className="flex items-center gap-2 bg-gradient-to-l from-emerald-500 to-cyan-500 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-lg shadow-emerald-200">
          <Plus size={16} /> عملية بيع جديدة
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
          <p className="text-[10px] text-gray-500">عدد العمليات</p><p className="text-lg font-bold text-gray-800">{filtered.length}</p>
        </div>
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
          <p className="text-[10px] text-gray-500">إجمالي المبيعات</p><p className="text-lg font-bold text-emerald-600">{formatCurrency(totalRevenue)}</p>
        </div>
        <div className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
          <p className="text-[10px] text-gray-500">إجمالي الأرباح</p><p className="text-lg font-bold text-purple-600">{formatCurrency(totalProfit)}</p>
        </div>
      </div>

      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="text" placeholder="بحث..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" />
        </div>
        <input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)}
          className="px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 bg-white text-sm" />
      </div>

      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowForm(false)}>
          <div className="bg-white rounded-xl p-5 w-full max-w-lg shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-gray-800 mb-4">عملية بيع جديدة</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">المنتج *</label>
                <select value={form.productId} onChange={(e) => handleProductChange(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 bg-white text-sm">
                  <option value="">اختر المنتج</option>
                  {products.filter((p) => p.quantity > 0).map((p) => (
                    <option key={p.id} value={p.id}>{p.name} (متاح: {p.quantity} {p.unit})</option>
                  ))}
                </select>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">الكمية *</label>
                  <input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" min="1" max={selectedProduct?.quantity || 999} />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">سعر البيع</label>
                  <input type="number" value={form.unitPrice} onChange={(e) => setForm({ ...form, unitPrice: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" min="0" step="0.01" />
                </div>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">اسم العميل</label>
                <input type="text" value={form.customerName} onChange={(e) => setForm({ ...form, customerName: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" placeholder="اختياري" list="customerNames" />
                <datalist id="customerNames">{customerNames.map((c) => <option key={c} value={c} />)}</datalist>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">التاريخ</label>
                <input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" />
              </div>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" checked={form.isPaid} onChange={() => setForm({ ...form, isPaid: true })} className="w-4 h-4 text-emerald-500" />
                  <span className="text-sm text-gray-700">مدفوع نقداً</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" checked={!form.isPaid} onChange={() => setForm({ ...form, isPaid: false })} className="w-4 h-4 text-red-500" />
                  <span className="text-sm text-gray-700">آجل (دين)</span>
                </label>
              </div>
              {selectedProduct && (
                <div className="p-3 bg-gray-50 rounded-lg space-y-1.5 text-xs">
                  <div className="flex justify-between"><span className="text-gray-500">الإجمالي:</span><span className="font-bold text-gray-800">{formatCurrency(form.quantity * form.unitPrice)}</span></div>
                  <div className="flex justify-between"><span className="text-gray-500">الربح:</span><span className="font-bold text-emerald-600">{formatCurrency(form.quantity * (form.unitPrice - selectedProduct.buyPrice))}</span></div>
                </div>
              )}
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={handleSave} className="flex-1 bg-gradient-to-l from-emerald-500 to-cyan-500 text-white py-2 rounded-lg text-sm font-medium shadow-lg">تسجيل البيع</button>
              <button onClick={() => setShowForm(false)} className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">التاريخ</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">المنتج</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">العميل</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الكمية</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">السعر</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الإجمالي</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الربح</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الحالة</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">حذف</th>
                </tr>
              </thead>
              <tbody>
                {[...filtered].reverse().map((s) => (
                  <tr key={s.id} className="border-t border-gray-50 hover:bg-gray-50/50">
                    <td className="py-2.5 px-3 text-gray-500 text-[11px]">{formatDate(s.date)}</td>
                    <td className="py-2.5 px-3 font-medium text-gray-800">{s.productName}</td>
                    <td className="py-2.5 px-3 text-gray-600">{s.customerName || '-'}</td>
                    <td className="py-2.5 px-3 text-gray-600">{s.quantity}</td>
                    <td className="py-2.5 px-3 text-gray-600">{formatCurrency(s.unitPrice)}</td>
                    <td className="py-2.5 px-3 font-medium text-gray-800">{formatCurrency(s.totalPrice)}</td>
                    <td className="py-2.5 px-3 font-medium text-emerald-600">{formatCurrency(s.profit)}</td>
                    <td className="py-2.5 px-3">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${s.isPaid ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {s.isPaid ? 'مدفوع' : 'آجل'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3">
                      <button onClick={() => handleDelete(s.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded"><Trash2 size={14} /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-gray-400">
            <ShoppingCart size={40} className="mx-auto mb-3 text-gray-300" />
            <p className="font-medium">لا توجد مبيعات</p>
          </div>
        )}
      </div>
    </div>
  );
}
