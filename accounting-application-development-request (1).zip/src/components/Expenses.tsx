import { useState } from 'react';
import { Plus, Search, Receipt, Trash2, Edit2 } from 'lucide-react';
import { Expense } from '../types';
import { generateId, formatCurrency, formatDate, getTodayStr } from '../store';

interface ExpensesProps {
  expenses: Expense[];
  setExpenses: (expenses: Expense[]) => void;
}

const EXPENSE_CATEGORIES = ['إيجار', 'رواتب', 'كهرباء وماء', 'نقل وشحن', 'صيانة', 'إعلانات', 'مواد استهلاكية', 'أخرى'];

export function Expenses({ expenses, setExpenses }: ExpensesProps) {
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [form, setForm] = useState({
    description: '',
    amount: 0,
    category: '',
    date: getTodayStr(),
  });

  const filtered = expenses.filter((e) => {
    const matchSearch = e.description.includes(search) || e.category.includes(search);
    const matchCategory = !filterCategory || e.category === filterCategory;
    return matchSearch && matchCategory;
  });

  const totalExpenses = filtered.reduce((sum, e) => sum + e.amount, 0);
  const categories = [...new Set(expenses.map(e => e.category))];

  // Group by category
  const byCategory: Record<string, number> = {};
  filtered.forEach(e => {
    byCategory[e.category] = (byCategory[e.category] || 0) + e.amount;
  });

  function handleSave() {
    if (!form.description || form.amount <= 0) return;

    if (editingId) {
      setExpenses(expenses.map(e => e.id === editingId ? { ...e, ...form } : e));
    } else {
      const expense: Expense = {
        id: generateId(),
        ...form,
      };
      setExpenses([...expenses, expense]);
    }
    resetForm();
  }

  function resetForm() {
    setShowForm(false);
    setEditingId(null);
    setForm({ description: '', amount: 0, category: '', date: getTodayStr() });
  }

  function handleEdit(expense: Expense) {
    setForm({ description: expense.description, amount: expense.amount, category: expense.category, date: expense.date });
    setEditingId(expense.id);
    setShowForm(true);
  }

  function handleDelete(id: string) {
    if (confirm('هل أنت متأكد من حذف هذا المصروف؟')) {
      setExpenses(expenses.filter(e => e.id !== id));
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">المصروفات</h2>
          <p className="text-gray-500 text-sm mt-0.5">تسجيل ومتابعة المصروفات التشغيلية</p>
        </div>
        <button
          onClick={() => { resetForm(); setShowForm(true); }}
          className="flex items-center gap-2 bg-gradient-to-l from-rose-500 to-pink-500 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-lg shadow-rose-200 hover:shadow-xl transition-all"
        >
          <Plus size={16} />
          إضافة مصروف
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500">إجمالي المصروفات</p>
          <p className="text-xl font-bold text-rose-600 mt-1">{formatCurrency(totalExpenses)}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500">عدد المصروفات</p>
          <p className="text-xl font-bold text-gray-800 mt-1">{filtered.length}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <p className="text-xs text-gray-500">عدد الأصناف</p>
          <p className="text-xl font-bold text-gray-800 mt-1">{Object.keys(byCategory).length}</p>
        </div>
      </div>

      {/* Category breakdown */}
      {Object.keys(byCategory).length > 0 && (
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <h3 className="text-sm font-bold text-gray-700 mb-3">توزيع المصروفات حسب الفئة</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {Object.entries(byCategory).sort((a, b) => b[1] - a[1]).map(([cat, amount]) => (
              <div key={cat} className="bg-gray-50 rounded-lg p-3">
                <p className="text-xs text-gray-500">{cat}</p>
                <p className="text-sm font-bold text-gray-800 mt-1">{formatCurrency(amount)}</p>
                <div className="w-full h-1 bg-gray-200 rounded mt-2">
                  <div
                    className="h-full bg-rose-400 rounded"
                    style={{ width: `${(amount / totalExpenses) * 100}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-2">
        <div className="relative flex-1">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="بحث..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-rose-500/30 focus:border-rose-400 text-sm"
          />
        </div>
        <select
          value={filterCategory}
          onChange={(e) => setFilterCategory(e.target.value)}
          className="px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-rose-500/30 bg-white text-sm"
        >
          <option value="">كل الفئات</option>
          {categories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {/* Form Modal */}
      {showForm && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={resetForm}>
          <div className="bg-white rounded-xl p-5 w-full max-w-md shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-gray-800 mb-4">
              {editingId ? 'تعديل المصروف' : 'إضافة مصروف جديد'}
            </h3>
            <div className="space-y-3">
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">الوصف *</label>
                <input
                  type="text"
                  value={form.description}
                  onChange={(e) => setForm({ ...form, description: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-rose-500/30 text-sm"
                  placeholder="وصف المصروف"
                />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">المبلغ *</label>
                  <input
                    type="number"
                    value={form.amount || ''}
                    onChange={(e) => setForm({ ...form, amount: Number(e.target.value) })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-rose-500/30 text-sm"
                    min="0"
                    step="0.01"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-600 mb-1">الفئة</label>
                  <select
                    value={form.category}
                    onChange={(e) => setForm({ ...form, category: e.target.value })}
                    className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-rose-500/30 bg-white text-sm"
                  >
                    <option value="">اختر الفئة</option>
                    {EXPENSE_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-600 mb-1">التاريخ</label>
                <input
                  type="date"
                  value={form.date}
                  onChange={(e) => setForm({ ...form, date: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-rose-500/30 text-sm"
                />
              </div>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={handleSave} className="flex-1 bg-gradient-to-l from-rose-500 to-pink-500 text-white py-2 rounded-lg text-sm font-medium shadow-lg">
                {editingId ? 'تحديث' : 'إضافة'}
              </button>
              <button onClick={resetForm} className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 hover:bg-gray-50 text-sm">
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-right py-3 px-4 text-gray-600 font-semibold text-xs">التاريخ</th>
                  <th className="text-right py-3 px-4 text-gray-600 font-semibold text-xs">الوصف</th>
                  <th className="text-right py-3 px-4 text-gray-600 font-semibold text-xs">الفئة</th>
                  <th className="text-right py-3 px-4 text-gray-600 font-semibold text-xs">المبلغ</th>
                  <th className="text-right py-3 px-4 text-gray-600 font-semibold text-xs">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {[...filtered].reverse().map((e) => (
                  <tr key={e.id} className="border-t border-gray-50 hover:bg-gray-50/50">
                    <td className="py-2.5 px-4 text-gray-500 text-xs">{formatDate(e.date)}</td>
                    <td className="py-2.5 px-4 font-medium text-gray-800 text-xs">{e.description}</td>
                    <td className="py-2.5 px-4">
                      <span className="px-2 py-0.5 bg-rose-50 text-rose-600 rounded text-[11px] font-medium">{e.category || '-'}</span>
                    </td>
                    <td className="py-2.5 px-4 font-bold text-rose-600 text-xs">{formatCurrency(e.amount)}</td>
                    <td className="py-2.5 px-4">
                      <div className="flex gap-1">
                        <button onClick={() => handleEdit(e)} className="p-1.5 text-blue-500 hover:bg-blue-50 rounded"><Edit2 size={14} /></button>
                        <button onClick={() => handleDelete(e.id)} className="p-1.5 text-red-500 hover:bg-red-50 rounded"><Trash2 size={14} /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-gray-400">
            <Receipt size={40} className="mx-auto mb-3 text-gray-300" />
            <p className="font-medium">لا توجد مصروفات</p>
            <p className="text-xs mt-1">ابدأ بتسجيل المصروفات التشغيلية</p>
          </div>
        )}
      </div>
    </div>
  );
}
