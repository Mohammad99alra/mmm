import { useState } from 'react';
import { Plus, Search, CreditCard, User, Phone, Trash2, CheckCircle, DollarSign } from 'lucide-react';
import { Customer } from '../types';
import { generateId, formatCurrency, formatDate, getTodayStr } from '../store';

interface DebtsProps {
  customers: Customer[];
  setCustomers: (customers: Customer[]) => void;
}

export function Debts({ customers, setCustomers }: DebtsProps) {
  const [showPayment, setShowPayment] = useState<string | null>(null);
  const [showAddCustomer, setShowAddCustomer] = useState(false);
  const [search, setSearch] = useState('');
  const [paymentAmount, setPaymentAmount] = useState(0);
  const [paymentNote, setPaymentNote] = useState('');
  const [newCustomer, setNewCustomer] = useState({ name: '', phone: '' });
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);

  const filtered = customers.filter((c) => c.name.includes(search) || c.phone.includes(search));
  const totalOwed = customers.reduce((sum, c) => sum + c.totalOwed, 0);
  const customersWithDebt = customers.filter((c) => c.totalOwed > 0);

  function handleAddCustomer() {
    if (!newCustomer.name) return;
    setCustomers([...customers, { id: generateId(), name: newCustomer.name, phone: newCustomer.phone, totalOwed: 0, transactions: [] }]);
    setNewCustomer({ name: '', phone: '' });
    setShowAddCustomer(false);
  }

  function handlePayment(customerId: string) {
    if (paymentAmount <= 0) return;
    setCustomers(customers.map((c) => c.id === customerId ? {
      ...c, totalOwed: Math.max(0, c.totalOwed - paymentAmount),
      transactions: [...c.transactions, { id: generateId(), type: 'payment' as const, amount: paymentAmount, date: getTodayStr(), note: paymentNote || 'دفعة' }],
    } : c));
    setShowPayment(null);
    setPaymentAmount(0);
    setPaymentNote('');
  }

  function handleDeleteCustomer(id: string) {
    if (confirm('حذف هذا العميل؟')) setCustomers(customers.filter((c) => c.id !== id));
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold text-gray-800">المبالغ المستحقة</h2>
          <p className="text-gray-500 text-xs mt-0.5">إدارة ديون العملاء</p>
        </div>
        <button onClick={() => setShowAddCustomer(true)}
          className="flex items-center gap-2 bg-gradient-to-l from-amber-500 to-orange-500 text-white px-4 py-2 rounded-lg text-sm font-medium shadow-lg shadow-amber-200">
          <Plus size={16} /> إضافة عميل
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-gradient-to-br from-red-500 to-rose-600 rounded-xl p-4 text-white shadow-lg">
          <div className="flex items-center gap-1.5 mb-1"><CreditCard size={16} /><span className="text-xs opacity-90">إجمالي الديون</span></div>
          <p className="text-xl font-bold">{formatCurrency(totalOwed)}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center gap-1.5 mb-1"><User size={16} className="text-gray-400" /><span className="text-xs text-gray-500">مدينون</span></div>
          <p className="text-xl font-bold text-gray-800">{customersWithDebt.length}</p>
        </div>
        <div className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
          <div className="flex items-center gap-1.5 mb-1"><DollarSign size={16} className="text-gray-400" /><span className="text-xs text-gray-500">إجمالي العملاء</span></div>
          <p className="text-xl font-bold text-gray-800">{customers.length}</p>
        </div>
      </div>

      <div className="relative">
        <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
        <input type="text" placeholder="بحث عن عميل..." value={search} onChange={(e) => setSearch(e.target.value)}
          className="w-full pr-9 pl-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-amber-500/30 text-sm" />
      </div>

      {showAddCustomer && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowAddCustomer(false)}>
          <div className="bg-white rounded-xl p-5 w-full max-w-md shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-gray-800 mb-4">إضافة عميل</h3>
            <div className="space-y-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">اسم العميل *</label>
                <input type="text" value={newCustomer.name} onChange={(e) => setNewCustomer({ ...newCustomer, name: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" placeholder="الاسم" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">الهاتف</label>
                <input type="tel" value={newCustomer.phone} onChange={(e) => setNewCustomer({ ...newCustomer, phone: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" placeholder="رقم الهاتف" />
              </div>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={handleAddCustomer} className="flex-1 bg-gradient-to-l from-amber-500 to-orange-500 text-white py-2 rounded-lg text-sm font-medium shadow-lg">إضافة</button>
              <button onClick={() => setShowAddCustomer(false)} className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      {showPayment && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowPayment(null)}>
          <div className="bg-white rounded-xl p-5 w-full max-w-md shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold text-gray-800 mb-4">تسجيل دفعة</h3>
            <div className="space-y-3">
              <div className="p-2.5 bg-amber-50 rounded-lg text-xs">
                المستحق: <span className="font-bold text-amber-700">{formatCurrency(customers.find((c) => c.id === showPayment)?.totalOwed || 0)}</span>
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">مبلغ الدفعة *</label>
                <input type="number" value={paymentAmount || ''} onChange={(e) => setPaymentAmount(Number(e.target.value))}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" min="0" step="0.01" />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">ملاحظة</label>
                <input type="text" value={paymentNote} onChange={(e) => setPaymentNote(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-gray-200 text-sm" placeholder="اختياري" />
              </div>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={() => handlePayment(showPayment)} className="flex-1 bg-gradient-to-l from-emerald-500 to-cyan-500 text-white py-2 rounded-lg text-sm font-medium shadow-lg">تسجيل</button>
              <button onClick={() => setShowPayment(null)} className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 text-sm">إلغاء</button>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-3">
        {filtered.length > 0 ? filtered.map((customer) => (
          <div key={customer.id} className={`bg-white rounded-xl shadow-sm border overflow-hidden ${customer.totalOwed > 0 ? 'border-red-100' : 'border-gray-100'}`}>
            <div className="p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 cursor-pointer hover:bg-gray-50/50"
              onClick={() => setSelectedCustomer(selectedCustomer === customer.id ? null : customer.id)}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center text-white font-bold ${customer.totalOwed > 0 ? 'bg-gradient-to-br from-red-400 to-rose-500' : 'bg-gradient-to-br from-emerald-400 to-cyan-500'}`}>
                  {customer.name.charAt(0)}
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 text-sm">{customer.name}</h4>
                  {customer.phone && <div className="flex items-center gap-1 text-[10px] text-gray-400"><Phone size={10} />{customer.phone}</div>}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="text-left">
                  <p className="text-[10px] text-gray-500">المستحق</p>
                  <p className={`text-lg font-bold ${customer.totalOwed > 0 ? 'text-red-600' : 'text-emerald-600'}`}>{formatCurrency(customer.totalOwed)}</p>
                </div>
                {customer.totalOwed > 0 && (
                  <button onClick={(e) => { e.stopPropagation(); setShowPayment(customer.id); }}
                    className="flex items-center gap-1 bg-emerald-500 text-white px-3 py-1.5 rounded-lg text-xs font-medium">
                    <CheckCircle size={14} /> تسديد
                  </button>
                )}
                <button onClick={(e) => { e.stopPropagation(); handleDeleteCustomer(customer.id); }}
                  className="p-1.5 text-red-400 hover:bg-red-50 rounded"><Trash2 size={14} /></button>
              </div>
            </div>
            {selectedCustomer === customer.id && customer.transactions.length > 0 && (
              <div className="border-t border-gray-100 px-4 py-3 bg-gray-50/50">
                <h5 className="text-xs font-semibold text-gray-600 mb-2">سجل المعاملات</h5>
                <div className="space-y-1.5 max-h-40 overflow-y-auto">
                  {[...customer.transactions].reverse().map((t) => (
                    <div key={t.id} className="flex items-center justify-between p-2 bg-white rounded-lg text-xs">
                      <div className="flex items-center gap-2">
                        <div className={`w-6 h-6 rounded flex items-center justify-center ${t.type === 'payment' ? 'bg-green-100' : 'bg-red-100'}`}>
                          {t.type === 'payment' ? <CheckCircle size={12} className="text-green-600" /> : <CreditCard size={12} className="text-red-600" />}
                        </div>
                        <div>
                          <p className="text-gray-700">{t.note}</p>
                          <p className="text-[10px] text-gray-400">{formatDate(t.date)}</p>
                        </div>
                      </div>
                      <span className={`font-bold ${t.type === 'payment' ? 'text-green-600' : 'text-red-600'}`}>
                        {t.type === 'payment' ? '-' : '+'}{formatCurrency(t.amount)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )) : (
          <div className="bg-white rounded-xl py-12 text-center shadow-sm border border-gray-100">
            <CreditCard size={40} className="mx-auto mb-3 text-gray-300" />
            <p className="font-medium text-gray-400">لا يوجد عملاء</p>
          </div>
        )}
      </div>
    </div>
  );
}
