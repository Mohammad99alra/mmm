import { useState } from 'react';
import { Search, Warehouse, AlertTriangle, CheckCircle, Package, Printer } from 'lucide-react';
import { Product } from '../types';
import { formatCurrency } from '../store';

interface InventoryProps {
  products: Product[];
}

export function Inventory({ products }: InventoryProps) {
  const [search, setSearch] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'low' | 'ok' | 'out'>('all');

  const filtered = products.filter((p) => {
    const matchSearch = p.name.includes(search) || p.category.includes(search);
    if (filterStatus === 'low') return matchSearch && p.quantity > 0 && p.quantity <= p.minQuantity;
    if (filterStatus === 'out') return matchSearch && p.quantity === 0;
    if (filterStatus === 'ok') return matchSearch && p.quantity > p.minQuantity;
    return matchSearch;
  });

  const totalValue = products.reduce((sum, p) => sum + p.quantity * p.buyPrice, 0);
  const totalSellValue = products.reduce((sum, p) => sum + p.quantity * p.sellPrice, 0);
  const totalItems = products.reduce((sum, p) => sum + p.quantity, 0);
  const outOfStock = products.filter((p) => p.quantity === 0).length;
  const lowStock = products.filter((p) => p.quantity > 0 && p.quantity <= p.minQuantity).length;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800">جرد المستودع</h2>
          <p className="text-gray-500 text-xs mt-0.5">الكميات المتبقية وحالة المخزون</p>
        </div>
        <button onClick={() => window.print()} className="flex items-center gap-1 text-xs text-gray-500 hover:text-gray-700 bg-white px-3 py-1.5 rounded-lg border border-gray-200 no-print">
          <Printer size={14} />
          طباعة
        </button>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3">
        {[
          { icon: <Warehouse size={16} className="text-blue-500" />, label: 'المنتجات', value: products.length.toString(), bg: 'bg-blue-50' },
          { icon: <Package size={16} className="text-emerald-500" />, label: 'الوحدات', value: totalItems.toLocaleString('ar-SA'), bg: 'bg-emerald-50' },
          { icon: <CheckCircle size={16} className="text-purple-500" />, label: 'قيمة (شراء)', value: formatCurrency(totalValue), bg: 'bg-purple-50' },
          { icon: <CheckCircle size={16} className="text-cyan-500" />, label: 'قيمة (بيع)', value: formatCurrency(totalSellValue), bg: 'bg-cyan-50' },
          { icon: <AlertTriangle size={16} className="text-red-500" />, label: 'تنبيهات', value: `${outOfStock + lowStock}`, bg: 'bg-red-50', extra: `${outOfStock} نفد · ${lowStock} منخفض` },
        ].map((s, i) => (
          <div key={i} className="bg-white rounded-xl p-3 shadow-sm border border-gray-100">
            <div className={`w-8 h-8 ${s.bg} rounded-lg flex items-center justify-center mb-2`}>{s.icon}</div>
            <p className="text-[10px] text-gray-500">{s.label}</p>
            <p className="text-sm font-bold text-gray-800">{s.value}</p>
            {s.extra && <p className="text-[10px] text-gray-400">{s.extra}</p>}
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-2 no-print">
        <div className="relative flex-1">
          <Search size={16} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400" />
          <input type="text" placeholder="بحث..." value={search} onChange={(e) => setSearch(e.target.value)}
            className="w-full pr-9 pl-3 py-2 rounded-lg border border-gray-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/30 text-sm" />
        </div>
        <div className="flex gap-1.5">
          {[
            { key: 'all' as const, label: 'الكل', count: products.length },
            { key: 'ok' as const, label: 'متوفر', count: products.filter(p => p.quantity > p.minQuantity).length },
            { key: 'low' as const, label: 'منخفض', count: lowStock },
            { key: 'out' as const, label: 'نفد', count: outOfStock },
          ].map((f) => (
            <button key={f.key} onClick={() => setFilterStatus(f.key)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-all ${
                filterStatus === f.key ? 'bg-emerald-500 text-white shadow' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
              }`}>
              {f.label} ({f.count})
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        {filtered.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead className="bg-gray-50">
                <tr>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">#</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">المنتج</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الصنف</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الكمية المتبقية</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الحد الأدنى</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">سعر الشراء</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">سعر البيع</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">القيمة</th>
                  <th className="text-right py-3 px-3 text-gray-600 font-semibold">الحالة</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p, i) => {
                  const status = p.quantity === 0
                    ? { label: 'نفد', color: 'bg-red-100 text-red-700' }
                    : p.quantity <= p.minQuantity
                    ? { label: 'منخفض', color: 'bg-amber-100 text-amber-700' }
                    : { label: 'متوفر', color: 'bg-green-100 text-green-700' };
                  const barPercent = p.minQuantity > 0 ? Math.min((p.quantity / (p.minQuantity * 3)) * 100, 100) : 100;
                  const barColor = p.quantity === 0 ? 'bg-red-500' : p.quantity <= p.minQuantity ? 'bg-amber-500' : 'bg-emerald-500';

                  return (
                    <tr key={p.id} className="border-t border-gray-50 hover:bg-gray-50/50">
                      <td className="py-2.5 px-3 text-gray-400">{i + 1}</td>
                      <td className="py-2.5 px-3 font-medium text-gray-800">{p.name}</td>
                      <td className="py-2.5 px-3"><span className="px-1.5 py-0.5 bg-gray-100 rounded text-[10px]">{p.category}</span></td>
                      <td className="py-2.5 px-3">
                        <div>
                          <span className="font-bold text-gray-800">{p.quantity} {p.unit}</span>
                          <div className="w-20 h-1 bg-gray-100 rounded-full mt-1">
                            <div className={`h-full rounded-full ${barColor}`} style={{ width: `${barPercent}%` }} />
                          </div>
                        </div>
                      </td>
                      <td className="py-2.5 px-3 text-gray-500">{p.minQuantity} {p.unit}</td>
                      <td className="py-2.5 px-3 text-gray-600">{formatCurrency(p.buyPrice)}</td>
                      <td className="py-2.5 px-3 text-gray-600">{formatCurrency(p.sellPrice)}</td>
                      <td className="py-2.5 px-3 font-medium text-gray-800">{formatCurrency(p.quantity * p.buyPrice)}</td>
                      <td className="py-2.5 px-3">
                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-medium ${status.color}`}>{status.label}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-gray-50 font-bold text-xs">
                <tr>
                  <td colSpan={3} className="py-3 px-3 text-gray-700">المجموع</td>
                  <td className="py-3 px-3 text-gray-800">{filtered.reduce((s, p) => s + p.quantity, 0).toLocaleString('ar-SA')}</td>
                  <td colSpan={3}></td>
                  <td className="py-3 px-3 text-emerald-700">{formatCurrency(filtered.reduce((s, p) => s + p.quantity * p.buyPrice, 0))}</td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        ) : (
          <div className="py-12 text-center text-gray-400">
            <Warehouse size={40} className="mx-auto mb-3 text-gray-300" />
            <p className="font-medium">المستودع فارغ</p>
          </div>
        )}
      </div>
    </div>
  );
}
