export interface Product {
  id: string;
  name: string;
  category: string;
  buyPrice: number;
  sellPrice: number;
  quantity: number;
  minQuantity: number;
  unit: string;
  barcode?: string;
  createdAt: string;
}

export interface Sale {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  buyPrice: number;
  totalPrice: number;
  profit: number;
  customerName: string;
  isPaid: boolean;
  date: string;
}

export interface Purchase {
  id: string;
  productId: string;
  productName: string;
  quantity: number;
  unitPrice: number;
  supplierName: string;
  isPaid: boolean;
  totalPrice: number;
  date: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  totalOwed: number;
  transactions: Transaction[];
}

export interface Transaction {
  id: string;
  type: 'sale' | 'payment';
  amount: number;
  date: string;
  note: string;
}

export interface Expense {
  id: string;
  description: string;
  amount: number;
  category: string;
  date: string;
}

export type ActivePage = 'dashboard' | 'products' | 'inventory' | 'sales' | 'purchases' | 'profits' | 'debts' | 'expenses' | 'settings';

export type CurrencyType = 'USD' | 'SAR' | 'IQD' | 'SYP' | 'AED' | 'EGP' | 'EUR';

export interface AppSettings {
  currency: CurrencyType;
  businessName: string;
}
